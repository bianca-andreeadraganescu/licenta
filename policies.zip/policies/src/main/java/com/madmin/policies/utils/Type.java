package com.madmin.policies.utils;

public enum Type {

    LAB,
    DEV,
    EXAM,
    DEFAULT
}
